<?php
/**
 * JSON-LD Class for Google Rich Cards.
 *
 * @package    EDD_Reviews
 * @subpackage Frontend
 * @copyright  Copyright (c) 2017, Sunny Ratilal
 * @since      2.1
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EDD_Reviews_JSON_LD {
	/**
	 * Constructor.
	 *
	 * @access public
	 * @since  2.1
	 */
	public function __construct() {
		$this->hooks();
	}

	/**
	 * Adds all the hooks/filters
	 *
	 * The plugin relies heavily on the use of hooks and filters and modifies
	 * default WordPress behaviour by the use of actions and filters which are
	 * provided by WordPress.
	 *
	 * Actions are provided to hook on this function, before the hooks and filters
	 * are added and after they are added. The class object is passed via the action.
	 *
	 * @access private
	 * @since  2.1
	 */
	private function hooks() {
		if ( class_exists( '\\EDD\\Structured_Data' ) ) {
			add_filter( 'edd_generate_download_structured_data', array( $this, 'add_ratings_to_data' ) );
		} else {
			add_action( 'wp_head', array( $this, 'json_ld_markup' ) );
		}
	}

	/**
	 * Adds the aggregateRating field to EDD's product markup.
	 *
	 * @see \EDD\Structured_Data::generate_download_data()
	 *
	 * @param array $data
	 *
	 * @return array
	 */
	public function add_ratings_to_data( $data ) {
		$rating_count = (int) edd_reviews()->count_reviews();

		if ( 0 === $rating_count ) {
			return $data;
		}

		$data['aggregateRating'] = array(
			'@type'       => 'AggregateRating',
			'ratingValue' => edd_reviews()->average_rating( false ),
			'bestRating'  => '5',
			'worstRating' => '1',
			'ratingCount' => $rating_count,
		);

		$review = $this->get_review();
		if ( ! empty( $review ) ) {
			$data['review'] = $review;
		}

		return $data;
	}

	/**
	 * Retrieves one review to add to the JSON.
	 *
	 * @since 2.2
	 *
	 * @return array|false
	 */
	private function get_review() {
		global $post;

		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		$reviews = edd_reviews()->query_reviews( array(
			'number' => 1,
		) );

		if ( ! isset( $reviews[0] ) ) {
			return false;
		}

		$review = $reviews[0];
		unset( $reviews );

		return array(
			'@type'        => 'Review',
			'reviewRating' => array(
				'@type'       => 'Rating',
				'ratingValue' => get_comment_meta( $review->comment_ID, 'edd_rating', true ),
				'bestRating'  => '5',
			),
			'author'       => array(
				'@type' => 'Person',
				'name'  => get_comment_author( $review ),
			)
		);
	}

	/**
	 * Generate the structured data from the post object.
	 *
	 * @deprecated 2.2 In favour of `add_ratings_to_data()` in EDD 3.0.
	 * @see        EDD_Reviews_JSON_LD::add_ratings_to_data()
	 *
	 * @access     private
	 * @since      2.1
	 * @return array $data Structured data for the JSON-LD markup.
	 */
	private function generate_structured_data() {
		global $post;

		$data = array(
			'@context'        => 'http://schema.org',
			'@type'           => 'Product',
			'name'            => strip_tags( get_the_title( $post ) ),
			'aggregateRating' => array(
				'@type'       => 'AggregateRating',
				'ratingValue' => edd_reviews()->average_rating( false ),
				'bestRating'  => '5',
				'worstRating' => '1',
				'ratingCount' => edd_reviews()->count_reviews(),
			),
		);

		$review = $this->get_review();
		if ( ! empty( $review ) ) {
			$data['review'] = $review;
		}

		/**
		 * Filter the JSON-LD markup that will be output.
		 *
		 * @since 2.1
		 *
		 * @param array               $data JSON-LD data.
		 * @param EDD_Reviews_JSON_LD $this Instance of EDD_Reviews_JSON_LD class.
		 */
		return apply_filters( 'edd_reviews_json_ld_data', $data, $this );
	}

	/**
	 * Generate the JSON-LD Markup.
	 *
	 * @deprecated 2.2 In favour of `add_ratings_to_data()` in EDD 3.0.
	 * @see        EDD_Reviews_JSON_LD::add_ratings_to_data()
	 *
	 * @access     public
	 * @since      2.1
	 */
	public function json_ld_markup() {
		if ( ! is_singular( 'download' ) ) {
			return;
		}

		$data = $this->generate_structured_data();

		if ( empty( $data ) ) {
			return;
		}

		if ( 0 == $data['aggregateRating']['ratingCount'] ) {
			return;
		}

		ob_start();
		?>
		<script type="application/ld+json">
		<?php echo json_encode( $data ); ?>
		</script>
		<?php
		echo ob_get_clean();
	}
}
