<?php
/**
 * Settings.php
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2022, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2.2
 */

namespace EDD\Reviews;

use EDD\Reviews\Interfaces\InitializerInterface;

class Settings implements InitializerInterface {

	/**
	 * @inheritDoc
	 */
	public function init() {
		$settings_tab = version_compare( EDD_VERSION, '2.11.4', '>=' ) && array_key_exists( 'marketing', edd_get_settings_tabs() ) ? 'marketing' : 'extensions';
		add_filter( "edd_settings_sections_{$settings_tab}", array( $this, 'register_section' ) );
		add_filter( 'edd_settings_sections_emails', array( $this, 'register_section' ) );
		add_filter( "edd_settings_{$settings_tab}", array( $this, 'misc_settings' ) );
		add_filter( 'edd_settings_emails', array( $this, 'settings_emails' ) );
	}

	/**
	 * Register section for Reviews settings.
	 *
	 * @since 2.0
	 * @access public
	 * @return array $sections Settings sections
	 */
	public function register_section( $sections ) {
		$sections['reviews'] = __( 'Reviews', 'edd-reviews' );

		return $sections;
	}

	/**
	 * Register Reviews settings.
	 *
	 * @since 1.0
	 * @access public
	 * @param array $settings Registered EDD settings
	 * @return array New settings
	 */
	public function misc_settings( $settings ) {
		$new = array(
			array(
				'id'   => 'edd_reviews_enable_breakdown',
				'name' => __( 'Enable Review Breakdown', 'edd-reviews' ),
				'desc' => __( 'This will show how many people have rated the download at each star rating. It will display at the top of the Reviews section on the download page.', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'      => 'edd_reviews_sorting',
				'name'    => __( 'Sort Reviews', 'edd-reviews' ),
				'desc'    => __( 'Set the order to display reviews.', 'edd-reviews' ),
				'type'    => 'select',
				'options' => array(
					'desc' => __( 'Newest First', 'edd-reviews' ),
					'asc'  => __( 'Oldest First', 'edd-reviews' ),
				),
			),
			array(
				'id'   => 'edd_reviews_disable_multiple_reviews',
				'name' => __( 'Disable Multiple Reviews By Same Author', 'edd-reviews' ),
				'desc' => __( 'This will disallow authors to post multiple reviews on the same download.', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_disable_voting',
				'name' => __( 'Disable Voting On Reviews', 'edd-reviews' ),
				'desc' => __( 'Disables the voting feature that is displayed under each review.', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_only_allow_reviews_by_buyer',
				'name' => __( 'Only Allow Reviews By Buyers', 'edd-reviews' ),
				'desc' => __( 'This will only allow customers who have purchased the download to review it. It will require them to login in order for the purchase to be verified.', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_display_review_link_in_purchase_receipt',
				'name' => __( 'Display Review Link in Purchase Receipt', 'edd-reviews' ),
				'desc' => sprintf( __( 'This will display a link next to the name of a %s to allow customers to leave a review .', 'edd-reviews' ), strtolower( edd_get_label_singular() ) ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_disable_own_reviews',
				'name' => sprintf( __( 'Disable Reviews By %s Author', 'edd-reviews' ), edd_get_label_singular() ),
				'desc' => sprintf( __( 'This will only allow the %s author to reply to reviews and not post reviews themselves.', 'edd-reviews' ), strtolower( edd_get_label_singular() ) ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_delay_posting',
				'name' => __( 'Delay Review Posting', 'edd-reviews' ),
				'desc' => sprintf( __( 'Enter the number of days that a customer will have to wait before posting a review of the %s purchased. Enter 0 for no delay.', 'edd-reviews' ), strtolower( edd_get_label_singular() ) ),
				'type' => 'text',
				'size' => 'small',
				'std'  => '0',
			),
			array(
				'id'   => 'edd_reviews_enable_guest_reviews',
				'name' => __( 'Enable Guest Reviews', 'edd-reviews' ),
				'desc' => __( 'Check this box to allow reviews to be left by guests (unauthenticated visitors).', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_minimum_word_count',
				'name' => __( 'Minimum Word Count', 'edd-reviews' ),
				'desc' => __( 'This will enforce a minimum word count for reviews.', 'edd-reviews' ),
				'type' => 'text',
				'size' => 'small',
				'std'  => '',
			),
			array(
				'id'   => 'edd_reviews_maximum_word_count',
				'name' => __( 'Maximum Word Count', 'edd-reviews' ),
				'desc' => __( 'This will enforce a maximum word count for reviews.', 'edd-reviews' ),
				'type' => 'text',
				'size' => 'small',
				'std'  => '',
			),
			array(
				'id'   => 'edd_reviews_disable_css',
				'name' => __( 'Disable EDD Reviews CSS', 'edd-reviews' ),
				'desc' => __( 'Check this to disable styling for the reviews provided by the EDD Reviews plugin.', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_uninstall_on_delete',
				'name' => __( 'Remove Data on Uninstall?', 'edd-reviews' ),
				'desc' => __( 'Check this box if you would like Reviews to completely remove all of its data when the plugin is deleted.', 'edd-reviews' ),
				'type' => 'checkbox',
			),
			array(
				'id'   => 'edd_reviews_settings_reviewer_discount',
				'name' => '<h3>' . __( 'Reviewer Discount', 'edd-reviews' ) . '</h3>',
				'type' => 'header',
			),
			array(
				'id'   => 'edd_reviews_reviewer_discount',
				'name' => __( 'Enable Reviewer Discount', 'edd-reviews' ),
				'desc' => __( 'This will email each reviewer a discount code to use once their review has been approved. The discount they are given is a one-time use discount.', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_reviewer_discount_amount',
				'name' => __( 'Reviewer Discount Amount', 'edd-reviews' ),
				'desc' => __( 'The percentage discount amount that will be provided to each reviewer. For example: for 10%, enter 10. (Only applicable if the reviewer discount option is enabled.)', 'edd-reviews' ),
				'type' => 'text',
				'size' => 'small',
				'std'  => '',
			),
		);

		if ( edd_reviews()->is_fes_installed() ) {
			$fes_settings = array(
				array(
					'id'   => 'edd_reviews_vendor_feedback_settings',
					'name' => '<h3>' . __( 'Vendor Feedback', 'edd-reviews' ) . '</h3>',
					'type' => 'header',
				),
				array(
					'id'          => 'edd_reviews_vendor_feedback_page',
					'name'        => __( 'Vendor Feedback Page', 'edd-reviews' ),
					'desc'        => __( 'The page where customers can go to leave feedback for vendors of downloads.', 'edd-reviews' ),
					'type'        => 'select',
					'options'     => edd_get_pages(),
					'chosen'      => true,
					'placeholder' => __( 'Select a page', 'edd-reviews' ),
				),
				array(
					'id'   => 'edd_reviews_vendor_feedback_table_heading',
					'name' => __( 'Vendor Feedback Heading', 'edd-reviews' ),
					'desc' => __( 'The heading label used on the Purchase History table', 'edd-reviews' ),
					'type' => 'text',
					'std'  => __( 'Feedback', 'edd-reviews' ),
					'size' => 'regular',
				),
				array(
					'id'   => 'edd_reviews_vendor_feedback_table_label',
					'name' => __( 'Vendor Feedback Link Text', 'edd-reviews' ),
					'desc' => __( 'The text for the link to provide Vendor Feedback displayed on the Purchase History table', 'edd-reviews' ),
					'type' => 'text',
					'std'  => __( 'Give Feedback', 'edd-reviews' ),
					'size' => 'regular',
				),
				array(
					'id'   => 'edd_reviews_vendor_feedback_form_heading',
					'name' => __( 'Vendor Feedback Form Heading', 'edd-reviews' ),
					'desc' => __( 'The text displayed above the Vendor Feedback form', 'edd-reviews' ),
					'type' => 'text',
					'std'  => __( 'Rate Your Experience', 'edd-reviews' ),
					'size' => 'regular',
				),
			);

			$new = array_merge( $new, $fes_settings );
		}

		return array_merge( $settings, array( 'reviews' => $new ) );
	}

	/**
	 * Register Email Settings for Reviews.
	 *
	 * @since  2.1
	 * @access public
	 *
	 * @param array $settings Registered EDD settings
	 * @return array New settings
	 */
	public function settings_emails( $settings ) {
		$reviews_settings = array(
			array(
				'id'   => 'edd_reviews_settings_emails',
				'name' => '<h3>' . __( 'Review Notification Emails', 'edd-reviews' ) . '</h3>',
				'type' => 'header',
			),
			array(
				'id'   => 'edd_reviews_settings_emails_toggle',
				'name' => __( 'Send Notifications For All Reviews', 'edd-reviews' ),
				'desc' => __( 'Check this to send an email notification for all reviews. Uncheck to only send an email notification when a posted review needs moderated.', 'edd-reviews' ),
				'type' => 'checkbox',
				'size' => 'regular',
			),
			array(
				'id'   => 'edd_reviews_settings_emails_subject',
				'name' => __( 'Review Notification Subject', 'edd-reviews' ),
				'desc' => __( 'Enter the subject line for the review notification email', 'edd-reviews' ),
				'type' => 'text',
				'size' => 'regular',
				'std'  => '',
			),
			array(
				'id'   => 'edd_reviews_settings_emails_notification',
				'name' => __( 'Review Notification', 'edd-reviews' ),
				'desc' => __( 'Enter the text that is sent as review notification email after completion of a purchase. HTML is accepted.', 'edd-reviews' ) . '<br />' . edd_reviews()->email_tags->get_tags_list( 'review_notification' ),
				'type' => 'rich_editor',
				'std'  => $this->get_default_review_notification_email(),
			),
			array(
				'id'   => 'edd_reviews_settings_emails_admin_emails',
				'name' => __( 'Review Notification Emails', 'edd-reviews' ),
				'desc' => __( 'Enter the email address(es) that should receive a notification anytime a review is posted, one per line.', 'edd-reviews' ),
				'type' => 'textarea',
				'std'  => get_bloginfo( 'admin_email' ),
			),
			array(
				'id'   => 'edd_reviews_settings_emails_disable_notifications',
				'name' => __( 'Disable Review Notifications', 'edd-reviews' ),
				'desc' => __( 'Check this box if you do not want to receive review notification emails.', 'edd-reviews' ),
				'type' => 'checkbox',
			),
			array(
				'id'   => 'edd_reviews_settings_reviewer_discount',
				'name' => '<h3>' . __( 'Reviewer Discount', 'edd-reviews' ) . '</h3>',
				'type' => 'header',
			),
			array(
				'id'   => 'edd_reviews_reviewer_discount_subject',
				'name' => __( 'Reviewer Discount Email Subject', 'edd-reviews' ),
				'desc' => __( 'Enter the subject line for the reviewer discount email', 'edd-reviews' ),
				'type' => 'text',
				'size' => 'regular',
				'std'  => '',
			),
			array(
				'id'   => 'edd_reviews_reviewer_discount_email',
				'name' => __( 'Reviewer Discount Email', 'edd-reviews' ),
				'desc' => __( 'Enter the text that will be sent to a reviewer giving them a discount. HTML is accepted.', 'edd-reviews' ) . '<br />' . edd_reviews()->email_tags->get_tags_list( 'discount' ),
				'type' => 'rich_editor',
				'std'  => $this->get_default_reviewer_discount_email(),
			),
		);

		if ( edd_reviews()->is_fes_installed() ) {
			add_filter( 'edd_reviews_email_tags', array( edd_reviews()->fes, 'email_tags' ) );

			$fes_settings = array(
				array(
					'id'   => 'edd_reviews_vendor_feedback_settings',
					'name' => '<h3>' . __( 'Vendor Feedback', 'edd-reviews' ) . '</h3>',
					'type' => 'header',
				),
				array(
					'id'   => 'edd_reviews_vendor_feedback_subject',
					'name' => __( 'Vendor Feedback Email Subject', 'edd-reviews' ),
					'desc' => __( 'Enter the subject line for the vendor feedback email', 'edd-reviews' ),
					'type' => 'text',
					'size' => 'regular',
				),
				array(
					'id'   => 'edd_reviews_vendor_feedback_email',
					'name' => __( 'Vendor Feedback Email', 'edd-reviews' ),
					'desc' => __( 'Enter the text that is sent to a vendor when feedback is posted. HTML is accepted.', 'edd-reviews' ) . '<br />' . edd_reviews()->email_tags->get_tags_list(),
					'type' => 'rich_editor',
					'std'  => edd_reviews()->fes->get_default_email(),
				),
			);

			$reviews_settings = array_merge( $reviews_settings, $fes_settings );

			remove_filter( 'edd_reviews_email_tags', array( edd_reviews()->fes, 'email_tags' ) );
		}

		/**
		 * Filter the email settings.
		 *
		 * @since 2.1
		 *
		 * @param array $reviews_settings Email settings.
		 */
		$reviews_settings = apply_filters( 'edd_reviews_email_settings', $reviews_settings );

		return array_merge( $settings, array( 'reviews' => $reviews_settings ) );
	}

	/**
	 * Gets the default review notification email body.
	 *
	 * @since 2.2.2
	 * @return string
	 */
	public function get_default_review_notification_email() {
		$default_email_body  = sprintf( __( 'A new review on the %s {download} is waiting for your approval', 'edd-reviews' ), strtolower( edd_get_label_singular() ) ) . "\n";
		$default_email_body .= '{direct_link}' . "\n\n";
		$default_email_body .= '<strong>' . __( 'Author:', 'edd-reviews' ) . '</strong>' . ' {author}' . "\n";
		$default_email_body .= '<strong>' . __( 'Email:', 'edd-reviews' ) . '</strong>' . ' {email}' . "\n";
		$default_email_body .= '<strong>' . __( 'URL:', 'edd-reviews' ) . '</strong>' . ' {url}' . "\n";
		$default_email_body .= '<strong>' . __( 'Rating:', 'edd-reviews' ) . '</strong>' . ' {rating}' . "\n";
		$default_email_body .= '<strong>' . __( 'Review Title:', 'edd-reviews' ) . '</strong>' . ' {title}' . "\n";
		$default_email_body .= '<strong>' . __( 'Review:', 'edd-reviews' ) . '</strong>' . "\n" . '{review}' . "\n\n";

		return $default_email_body;
	}

	/**
	 * Gets the default reviewer discount email body.
	 *
	 * @since  2.2.2
	 * @return string Reviewer discount email.
	 */
	public function get_default_reviewer_discount_email() {
		$default_email_body  = __( "Thank you for reviewing {download}. As a gesture of our appreciation, we'd like to give you a discount code to use on a future purchase.", 'edd-reviews' ) . "\n\n";
		$default_email_body .= '<strong>' . __( 'Discount code:', 'edd-reviews' ) . '</strong>' . ' {reviewer_discount_code}' . "\n";

		return $default_email_body;
	}
}
