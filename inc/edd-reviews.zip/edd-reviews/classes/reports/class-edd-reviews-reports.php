<?php
/**
 * EDD Reviews Reports.
 *
 * @package    EDD_Reviews
 * @subpackage Admin/Reports
 * @copyright  Copyright (c) 2017, Sunny Ratilal
 * @since      2.1
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'EDD_Reviews_Reports' ) ) :

	/**
	 * EDD_Reviews_Reports Class
	 *
	 * @package EDD_Reviews
	 * @since   2.1
	 * @version 1.0
	 * @author  Sunny Ratilal
	 */
	class EDD_Reviews_Reports {
		/**
		 * Constructor.
		 *
		 * @access protected
		 * @since 2.1
		 */
		public function __construct() {
			$this->hooks();
		}

		/**
		 * Adds all the hooks/filters
		 *
		 * The plugin relies heavily on the use of hooks and filters and modifies
		 * default WordPress behaviour by the use of actions and filters which are
		 * provided by WordPress.
		 *
		 * Actions are provided to hook on this function, before the hooks and filters
		 * are added and after they are added. The class object is passed via the action.
		 *
		 * @since 2.1
		 * @access private
		 * @return void
		 */
		private function hooks() {
			// EDD 3.0
			if ( function_exists( 'edd_get_orders' ) ) {
				add_action( 'edd_reports_init', array( $this, 'reports' ) );

				return;
			}

			// EDD 2.x
			add_filter( 'edd_report_views', array( $this, 'add_views' ) );

			add_action( 'edd_reports_view_reviews_highest_average_rating', array( $this, 'render_highest_average_rating_view' ) );
			add_action( 'edd_reports_view_reviews_lowest_average_rating', array( $this, 'render_lowest_average_rating_view' ) );
			add_action( 'edd_reports_view_reviews_most_reviewed', array( $this, 'render_most_reviewed_view' ) );
		}

		/**
		 * Registers the Reviews reports for EDD 3.0.
		 *
		 * @since 2.1.14
		 * @param \EDD\Reports\Data\Report_Registry $reports
		 * @return void
		 */
		public function reports( $reports ) {
			try {
				$tables = $this->get_tables();
				$reports->add_report(
					'reviews',
					array(
						'label'      => __( 'Reviews', 'edd-reviews' ),
						'icon'       => 'testimonial',
						'priority'   => 100,
						'capability' => 'view_shop_reports',
						'filters'    => false,
						'endpoints'  => array(
							'tables' => array_keys( $tables ),
						),
					)
				);

				foreach ( $tables as $key => $table ) {
					$reports->register_endpoint( $key, $table );
				}
			} catch ( \EDD_Exception $exception ) {
				edd_debug_log_exception( $exception );
			}
		}

		/**
		 * Gets the tables for the Reviews reports in EDD 3.0.
		 *
		 * @since 2.1.14
		 * @return array
		 */
		private function get_tables() {
			return array(
				'reviews_highest_average_table' => array(
					'label' => __( 'Highest Average Rating', 'edd-reviews' ),
					'views' => array(
						'table' => array(
							'display_args' => array(
								'class_name' => 'EDD_Reviews_Highest_Average_Rating_List_Table',
								'class_file' => 'class-edd-reviews-highest-average-rating-list-table.php',
							),
						),
					),
				),
				'reviews_lowest_average_table'  => array(
					'label' => __( 'Lowest Average Rating', 'edd-reviews' ),
					'views' => array(
						'table' => array(
							'display_args' => array(
								'class_name' => 'EDD_Reviews_Lowest_Average_Rating_List_Table',
								'class_file' => 'class-edd-reviews-lowest-average-rating-list-table.php',
							),
						),
					),
				),
				'reviews_most_reviewed_table'   => array(
					'label' => __( 'Most Reviewed', 'edd-reviews' ),
					'views' => array(
						'table' => array(
							'display_args' => array(
								'class_name' => 'EDD_Reviews_Most_Reviewed_List_Table',
								'class_file' => 'class-edd-reviews-most-reviewed-list-table.php',
							),
						),
					),
				),
			);
		}

		/**
		 * Add reviews reports to report views.
		 *
		 * @since 2.1
		 * @access public
		 * @param array $views The existing report views.
		 * @return array $views The views updated with reviews reports.
		 */
		public function add_views( $views ) {
			$views['reviews_highest_average_rating'] = __( 'Highest Average Rating', 'edd-reviews' );
			$views['reviews_lowest_average_rating']  = __( 'Lowest Average Rating', 'edd-reviews' );
			$views['reviews_most_reviewed']          = __( 'Most Reviewed', 'edd-reviews' );

			return $views;
		}

		/**
		 * Show Highest Average Rating Report.
		 *
		 * @since 2.1
		 * @access public
		 * @return void
		 */
		public function render_highest_average_rating_view() {
			$this->do_tablenav();
			?>
			<div class="postbox edd-reviews">
				<div class="inside">
					<h3><span><?php esc_html_e( 'Highest Average Rating', 'edd-reviews' ); ?></span></h3>

					<?php
					$list_table = new EDD_Reviews_Highest_Average_Rating_List_Table();
					$list_table->prepare_items();
					$list_table->display();
					?>
				</div>
			</div>
			<?php
		}

		/**
		 * Show Lowest Average Rating Report.
		 *
		 * @since 2.1
		 * @access public
		 * @return void
		 */
		public function render_lowest_average_rating_view() {
			$this->do_tablenav();
			?>
			<div class="postbox edd-reviews">
					<div class="inside">
						<h3><span><?php esc_html_e( 'Lowest Average Rating', 'edd-reviews' ); ?></span></h3>

						<?php
						$list_table = new EDD_Reviews_Lowest_Average_Rating_List_Table();
						$list_table->prepare_items();
						$list_table->display();
						?>
				</div>
			</div>
			<?php
		}

		/**
		 * Show Most Reviewed Report.
		 *
		 * @since 2.1
		 * @access public
		 * @return void
		 */
		public function render_most_reviewed_view() {
			$this->do_tablenav();
			?>
			<div class="postbox edd-reviews">
				<div class="inside">
					<h3><span><?php esc_html_e( 'Most Reviewed', 'edd-reviews' ); ?></span></h3>

					<?php
					$list_table = new EDD_Reviews_Most_Reviewed_List_Table();
					$list_table->prepare_items();
					$list_table->display();
					?>
				</div>
			</div>
			<?php
		}

		/**
		 * In EDD 2.x, this outputs the report views tablenav. Deprecated in EDD 3.0.
		 *
		 * @since 2.1.14
		 * @return void
		 */
		private function do_tablenav() {
			if ( function_exists( 'edd_get_orders' ) ) {
				return;
			}
			?>
			<div class="tablenav top">
				<div class="alignleft actions"><?php edd_report_views(); ?></div>
			</div>
			<?php
		}
	}

endif;
