<?php
/**
 * API Route Registration
 *
 * @package   edd-reviews
 * @copyright Copyright (c) 2021, Easy Digital Downloads
 * @license   GPL2+
 * @since     2.2
 */

namespace EDD\Reviews\API;

use EDD\Reviews\API\v1\Endpoint;

class RouteRegistration {

	private $routes = array(
		\EDD\Reviews\API\v1\Reviews::class,
		\EDD\Reviews\API\v1\Products::class,
	);

	public function __construct() {

	}

	/**
	 * Registers all API routes.
	 *
	 * @since 2.2
	 */
	public function registerRoutes() {
		foreach ( $this->routes as $route ) {
			/** @var Endpoint $route */
			$route = new $route;
			$route->register();
		}
	}

}
