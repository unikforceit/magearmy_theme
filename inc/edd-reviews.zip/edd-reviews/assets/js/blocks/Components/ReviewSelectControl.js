/* global eddReviews */

import apiFetch from '@wordpress/api-fetch';

const { Component } = wp.element;
const { __ } = wp.i18n;

class ReviewSelectControl extends Component {
	constructor( props ) {
		super( props );

		this.state = {
			productId: this.props.productId,
			selectedReview: null,
			reviewsLoaded: false,
			reviews: []
		};
	}

	componentDidUpdate( prevProps, prevState ) {
		if ( this.props.productId !== this.state.productId ) {
			this.setState( {
				productId: this.props.productId,
				reviewsLoaded: false
			} );
		}

		if ( this.state.productId !== prevState.productId ) {
			this.loadReviews();
		}

		if ( this.state.selectedReview !== prevState.selectedReview ) {
			this.onReviewChange();
		}
	}

	componentDidMount() {
		this.loadReviews();
	}

	loadReviews() {
		apiFetch.use( apiFetch.createNonceMiddleware( eddReviews.restNonce ) );
		apiFetch( { url: eddReviews.reviewsApi + '/product/' + this.state.productId } )
			.then( response => {
				let reviews = [],
					selectedReview = null;

				if ( response.data && response.data.length ) {
					reviews = response.data;
					selectedReview = response.data[0].id;
				}

				this.setState( {
					reviews,
					selectedReview
				} );
			} )
			.catch( e => {
				console.log( 'ReviewSelectControl Error', e );
			} )
			.finally( () => {
				this.setState( { reviewsLoaded: true } );
			} );
	}

	onReviewChange() {
		if ( typeof this.props.onChange === 'function' ) {
			this.props.onChange( this.state.selectedReview );
		}
	}

	render() {
		if ( ! this.state.reviewsLoaded ) {
			return (
				<p>{__( 'Loading reviews...', 'edd-reviews' )}</p>
			)
		}

		if ( ! this.state.reviews.length ) {
			return (
				<p>{__( 'No reviews for this product.', 'edd-reviews' )}</p>
			);
		}

		const reviews = this.state.reviews.map( review => {
			return (
				<option key={review.id} value={review.id}>
					{review.title}
				</option>
			)
		} );

		return (
			<div
				className="edd-reviews-editor__select"
			>
				<label
					className="components-input-control__label"
				>
					{__( 'Select a review', 'edd-reviews' )}
				</label>
				<select
					className="components-select-control__input"
					onChange={( e ) => this.setState( { selectedReview: e.target.value } )}
				>
					{reviews}
				</select>
			</div>
		)
	}
}

export default ReviewSelectControl;
