<?php
// Silence is golden

/**
 * PLEASE NOTE:
 * Do not modify files in this folder because all changes
 * will be removed on plugin upgrade.
 */