<?php

/**
 * Registers the EDD Reviews block
 *
 * @since 1.2
 * @return void
 */
function edd_reviews_block() {
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}

	$block_script = require_once plugin_dir_path( edd_reviews()->file ) . '/assets/build/blocks.asset.php';

	wp_register_script(
		'edd-review-block',
		plugins_url(
			'/assets/build/blocks.js',
			edd_reviews()->file
		),
		$block_script['dependencies'],
		$block_script['version'],
		true
	);

	wp_localize_script(
		'edd-review-block',
		'eddReviews',
		array(
			'productsApi' => rest_url( \EDD\Reviews\API\v1\Reviews::$namespace . '/products' ),
			'reviewsApi'  => rest_url( \EDD\Reviews\API\v1\Reviews::$namespace . '/reviews' ),
			'restNonce'   => wp_create_nonce( 'wp_rest' ),
		)
	);

	register_block_type(
		'edd-reviews/edd-review-block',
		array(
			'editor_script'   => 'edd-review-block',
			'render_callback' => 'edd_reviews_render_review_embed_block',
		)
	);
}

add_action( 'init', 'edd_reviews_block' );

/**
 * Renders the review block.
 *
 * @since 1.2
 *
 * @param array $atts Block attributes.
 *
 * @return string
 */
function edd_reviews_render_review_embed_block( $atts ) {
	return ! empty( $atts['id'] ) ? '[review id="' . esc_attr( $atts['id'] ) . '"]' : '';
}
