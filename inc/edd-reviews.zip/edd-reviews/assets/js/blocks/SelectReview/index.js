import SelectReview from "./SelectReview";

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

registerBlockType( 'edd-reviews/edd-review-block', {
	title: __( 'Reviews', 'edd-reviews'),
	description: __( 'A review block to use with EDD Reviews plugin', 'edd-reviews' ),
	icon: 'star-filled',
	category: 'widgets',

	attributes: {
		id: {
			type: 'string',
			default: ''
		}
	},

	edit(props) {
		return <SelectReview {...props} />
	}
} );
